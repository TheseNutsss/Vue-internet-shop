<script>
export default {

  methods: {
          
  }
}

</script>

<template>
<div class="container">
    <my-signup></my-signup>
</div>
</template>

<style scoped>

</style>