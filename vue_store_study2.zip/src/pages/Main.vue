<script>

</script>

<template>
<div class="banner-wrapper">
    <img src="@/images/banner.jpg" alt="banner image"/>
</div>
    
        
    
</template>

<style scoped>
.banner-wrapper img{
    width: 100%;
    height: 100%;
    background-size: cover;
    display: flex;
}
@media screen and (max-width: 968px) {
.banner-wrapper{
    height: 30vh;
}
}


</style>