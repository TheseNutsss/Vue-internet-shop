<script>

</script>

<template>
<div class="container">
  <my-auth></my-auth>
</div>
</template>

<style scoped>

</style>